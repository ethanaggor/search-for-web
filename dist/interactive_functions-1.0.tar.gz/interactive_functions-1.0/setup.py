from setuptools import setup

setup(
    name='interactive_functions',
    version='1.0',
    description='The Head First Python Search Tools',
    author='ethan aggor',
    py_modules=['interactive_functions'],
)